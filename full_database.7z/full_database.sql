-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: db_ventas
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_compra`
--

DROP TABLE IF EXISTS `tb_compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_compra` (
  `codigo_compra` int NOT NULL AUTO_INCREMENT,
  `codigo_us` int NOT NULL,
  `codigo_proveedor` int NOT NULL,
  `total` float NOT NULL,
  `fecha_creacion` date NOT NULL,
  PRIMARY KEY (`codigo_compra`),
  KEY `cod_us_idx` (`codigo_us`),
  KEY `cod_prov_idx` (`codigo_proveedor`),
  CONSTRAINT `cod_prov` FOREIGN KEY (`codigo_proveedor`) REFERENCES `tb_proveedor` (`codigo_prov`),
  CONSTRAINT `cod_us` FOREIGN KEY (`codigo_us`) REFERENCES `tb_usuarios` (`codigo_us`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_compra`
--

LOCK TABLES `tb_compra` WRITE;
/*!40000 ALTER TABLE `tb_compra` DISABLE KEYS */;
INSERT INTO `tb_compra` VALUES (1,2,1,897.5,'2024-05-10');
/*!40000 ALTER TABLE `tb_compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_detalle_compra`
--

DROP TABLE IF EXISTS `tb_detalle_compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_detalle_compra` (
  `codigo_compra` int NOT NULL,
  `codigo_prod` int NOT NULL,
  `cantidad` int NOT NULL,
  `precio_unit` float NOT NULL,
  KEY `cod_com_idx` (`codigo_compra`),
  KEY `cod_prod_idx` (`codigo_prod`),
  CONSTRAINT `cod_com` FOREIGN KEY (`codigo_compra`) REFERENCES `tb_compra` (`codigo_compra`),
  CONSTRAINT `cod_prod` FOREIGN KEY (`codigo_prod`) REFERENCES `tb_producto` (`codigo_pr`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_detalle_compra`
--

LOCK TABLES `tb_detalle_compra` WRITE;
/*!40000 ALTER TABLE `tb_detalle_compra` DISABLE KEYS */;
INSERT INTO `tb_detalle_compra` VALUES (1,1,20,12),(1,2,15,25.5),(1,10,10,27.5);
/*!40000 ALTER TABLE `tb_detalle_compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_detalle_venta`
--

DROP TABLE IF EXISTS `tb_detalle_venta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_detalle_venta` (
  `codigo_venta` int NOT NULL,
  `codigo_prod` int NOT NULL,
  `cantidad` int NOT NULL,
  `precio_unit` float NOT NULL,
  KEY `codigo_venta_idx` (`codigo_venta`),
  KEY `codigo_prod_idx` (`codigo_prod`),
  CONSTRAINT `codigo_prod` FOREIGN KEY (`codigo_prod`) REFERENCES `tb_producto` (`codigo_pr`),
  CONSTRAINT `codigo_venta` FOREIGN KEY (`codigo_venta`) REFERENCES `tb_venta` (`codigo_venta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_detalle_venta`
--

LOCK TABLES `tb_detalle_venta` WRITE;
/*!40000 ALTER TABLE `tb_detalle_venta` DISABLE KEYS */;
INSERT INTO `tb_detalle_venta` VALUES (1,1,1,15),(1,7,1,12);
/*!40000 ALTER TABLE `tb_detalle_venta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_familias`
--

DROP TABLE IF EXISTS `tb_familias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_familias` (
  `codigo_fa` int NOT NULL AUTO_INCREMENT,
  `nombre_fa` varchar(45) DEFAULT NULL,
  `descripcion_fa` varchar(45) DEFAULT NULL,
  `activo` bit(1) DEFAULT b'1',
  PRIMARY KEY (`codigo_fa`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_familias`
--

LOCK TABLES `tb_familias` WRITE;
/*!40000 ALTER TABLE `tb_familias` DISABLE KEYS */;
INSERT INTO `tb_familias` VALUES (1,'BEBIDAS','Productos liquidos envasados.',_binary ''),(2,'Frituras','Diferentes botanas',_binary ''),(3,'Cremeria','Productos originarios de ganado',_binary ''),(4,'Pan','Productos de pan dulce',_binary '');
/*!40000 ALTER TABLE `tb_familias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_producto`
--

DROP TABLE IF EXISTS `tb_producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_producto` (
  `codigo_pr` int NOT NULL AUTO_INCREMENT,
  `nombre_pr` varchar(45) DEFAULT NULL,
  `descripcion_pr` varchar(180) DEFAULT NULL,
  `codigo_manu` varchar(20) DEFAULT NULL,
  `pu_costo` decimal(18,2) DEFAULT NULL,
  `pu_venta` decimal(18,2) DEFAULT NULL,
  `codigo_us` int DEFAULT NULL,
  `codigo_fa` int DEFAULT NULL,
  `codigo_prov` int DEFAULT NULL,
  `fecha_crea` datetime DEFAULT NULL,
  `fecha_modifica` datetime DEFAULT NULL,
  `inventario` int DEFAULT '0',
  `activo` bit(1) DEFAULT b'1',
  PRIMARY KEY (`codigo_pr`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_producto`
--

LOCK TABLES `tb_producto` WRITE;
/*!40000 ALTER TABLE `tb_producto` DISABLE KEYS */;
INSERT INTO `tb_producto` VALUES (1,'Coca Cola 500ml Retornable','Coca cola botella de vidrio de 500 ml retornable con corcholata','CC500R',12.00,15.00,2,1,1,'2024-05-10 19:34:44','2024-05-10 19:34:44',19,_binary ''),(2,'Coca Cola 2.5L retornable','Coca Cola botella de plastico retornable de 2.5L con taparosca','CC25KT',25.50,27.00,2,1,1,'2024-05-10 19:38:01','2024-05-10 19:38:01',15,_binary ''),(3,'Doritos Nacho','Doritos Nacho bolsa de 57gr','SABDORN',15.10,17.00,2,2,2,'2024-05-10 19:39:35','2024-05-10 19:39:35',0,_binary ''),(4,'Mantecadas','Pan dulce sabor vainilla. Paquete con 4 piezas','BIMMAN',18.00,20.00,2,4,4,'2024-05-10 19:46:47','2024-05-10 19:46:47',0,_binary ''),(5,'Nito','Pan dulce cubierto de chocolate','BIMNITO',12.00,13.00,2,4,4,'2024-05-10 19:47:27','2024-05-10 19:47:27',0,_binary ''),(6,'Sabritas Flaming Hot Crujientes','Sabritas con sabor a Flaming Hot extra crujientes ','SABSFHC',15.00,17.00,2,2,2,'2024-05-10 19:49:37','2024-05-10 19:49:37',0,_binary ''),(7,'Cheetos Torciditos','Sheetos sabor queso picosito','SABCHET',11.00,12.00,2,2,2,'2024-05-10 19:50:58','2024-05-10 19:50:58',-1,_binary ''),(8,'Medias noches','Pan para preparar hotdogs','BIMMN',35.00,37.00,2,4,4,'2024-05-10 19:51:58','2024-05-10 19:51:58',0,_binary ''),(9,'Pan Blanco Grande','Pan Blanco Bimbo paquete grande','BIMPANG',51.00,54.00,2,4,4,'2024-05-10 19:53:02','2024-05-10 19:53:02',0,_binary ''),(10,'Coca Cola 1.7 L desechable','Coca cola desechable de 1.7 L taparrosca','CC17KD',27.50,30.00,2,1,1,'2024-05-10 19:54:49','2024-05-10 19:54:49',10,_binary '');
/*!40000 ALTER TABLE `tb_producto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_proveedor`
--

DROP TABLE IF EXISTS `tb_proveedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_proveedor` (
  `codigo_prov` int NOT NULL AUTO_INCREMENT,
  `nombre_prov` varchar(45) DEFAULT NULL,
  `direccion_prov` varchar(100) DEFAULT NULL,
  `telefono_prov` varchar(15) DEFAULT NULL,
  `codigo_us` int DEFAULT NULL,
  `activo` bit(1) DEFAULT b'1',
  PRIMARY KEY (`codigo_prov`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_proveedor`
--

LOCK TABLES `tb_proveedor` WRITE;
/*!40000 ALTER TABLE `tb_proveedor` DISABLE KEYS */;
INSERT INTO `tb_proveedor` VALUES (1,'Coca Cola','Manuel R Alatorre 3400','8007044400',2,_binary ''),(2,'Sabritas','Av Moctezuma 2300','3331787721',2,_binary ''),(3,'LALA','Tlaquepaque, Jalisco','3336684956',2,_binary ''),(4,'Bimbo','Av Roberto Michel 940','3336194532',2,_binary '');
/*!40000 ALTER TABLE `tb_proveedor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_roles_usuarios`
--

DROP TABLE IF EXISTS `tb_roles_usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_roles_usuarios` (
  `codigo_ru` int NOT NULL AUTO_INCREMENT,
  `descripcion_ru` varchar(45) DEFAULT NULL,
  `activo` bit(1) DEFAULT b'1',
  PRIMARY KEY (`codigo_ru`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_roles_usuarios`
--

LOCK TABLES `tb_roles_usuarios` WRITE;
/*!40000 ALTER TABLE `tb_roles_usuarios` DISABLE KEYS */;
INSERT INTO `tb_roles_usuarios` VALUES (1,'Administrador',_binary ''),(2,'Usuario',_binary '');
/*!40000 ALTER TABLE `tb_roles_usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_usuarios`
--

DROP TABLE IF EXISTS `tb_usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_usuarios` (
  `codigo_us` int NOT NULL AUTO_INCREMENT,
  `login_us` varchar(20) DEFAULT NULL,
  `password_us` varchar(20) DEFAULT NULL,
  `nombre_us` varchar(100) DEFAULT NULL,
  `codigo_ru` int DEFAULT NULL,
  `activo` bit(1) DEFAULT b'1',
  PRIMARY KEY (`codigo_us`),
  KEY `rol_user_idx` (`codigo_ru`),
  CONSTRAINT `rol_user` FOREIGN KEY (`codigo_ru`) REFERENCES `tb_roles_usuarios` (`codigo_ru`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_usuarios`
--

LOCK TABLES `tb_usuarios` WRITE;
/*!40000 ALTER TABLE `tb_usuarios` DISABLE KEYS */;
INSERT INTO `tb_usuarios` VALUES (1,'admin','1234','Administrador de sistema',1,_binary ''),(2,'namteleas','P4s5w0rd','Juan Flores',1,_binary ''),(3,'dummy','dummy','Dummy sin Admin',2,_binary '');
/*!40000 ALTER TABLE `tb_usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_venta`
--

DROP TABLE IF EXISTS `tb_venta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_venta` (
  `codigo_venta` int NOT NULL AUTO_INCREMENT,
  `codigo_us` int DEFAULT NULL,
  `fecha_creacion` date DEFAULT NULL,
  `total` float DEFAULT NULL,
  PRIMARY KEY (`codigo_venta`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_venta`
--

LOCK TABLES `tb_venta` WRITE;
/*!40000 ALTER TABLE `tb_venta` DISABLE KEYS */;
INSERT INTO `tb_venta` VALUES (1,2,'2024-05-10',27);
/*!40000 ALTER TABLE `tb_venta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'db_ventas'
--

--
-- Dumping routines for database 'db_ventas'
--
/*!50003 DROP PROCEDURE IF EXISTS `detalle_Compra` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `detalle_Compra`(in idcom int)
BEGIN
	SELECT codigo_pr, descripcion_pr, cantidad, tb_detalle_compra.precio_unit
    FROM tb_producto
    INNER JOIN tb_detalle_compra
    ON codigo_pr = codigo_prod
    INNER JOIN tb_compra
    ON tb_compra.codigo_compra = tb_detalle_compra.codigo_compra
    WHERE tb_detalle_compra.codigo_compra = idcom;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `detalle_Venta` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `detalle_Venta`(in idven int)
BEGIN
	SELECT codigo_pr, descripcion_pr, cantidad, tb_detalle_venta.precio_unit
    FROM tb_producto
    INNER JOIN tb_detalle_venta
    ON codigo_pr = codigo_prod
    INNER JOIN tb_venta
    ON tb_venta.codigo_venta = tb_detalle_venta.codigo_venta
    WHERE tb_detalle_venta.codigo_venta = idven;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_Buy_Item` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_Buy_Item`(IN codigo_producto CHAR(20), IN prov INT)
BEGIN
	SELECT codigo_pr, descripcion_pr, pu_costo
    FROM tb_producto
    WHERE codigo_manu = codigo_producto
    AND codigo_prov = prov
    AND activo = b'1';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_Compras` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_Compras`(in inicio date, in fin date)
BEGIN
	SELECT codigo_compra, nombre_us, fecha_creacion, total FROM tb_compra
    INNER JOIN tb_usuarios 
    ON tb_compra.codigo_us = tb_usuarios.codigo_us
    WHERE fecha_creacion >= inicio AND fecha_creacion <= fin;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_detalle_Inventario` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detalle_Inventario`(IN minInv INT)
BEGIN
	SELECT nombre_pr, nombre_fa, nombre_prov, inventario FROM tb_producto
    INNER JOIN tb_familias
    ON tb_producto.codigo_fa = tb_familias.codigo_fa
    INNER JOIN tb_proveedor
    ON tb_producto.codigo_prov = tb_proveedor.codigo_prov
    WHERE inventario < minInv;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_Store_Item` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_Store_Item`(IN codigo_producto CHAR(20))
BEGIN
	SELECT codigo_pr, descripcion_pr, pu_venta
    FROM tb_producto
    WHERE codigo_manu = codigo_producto
    AND activo = b'1';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_Ventas` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_Ventas`(in inicio date, in fin date)
BEGIN
	SELECT codigo_venta, nombre_us, fecha_creacion, total FROM tb_venta
    INNER JOIN tb_usuarios 
    ON tb_venta.codigo_us = tb_usuarios.codigo_us
    WHERE fecha_creacion >= inicio AND fecha_creacion <= fin;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `new_Buy` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `new_Buy`(in us int, in prov int, in f date, in total float)
BEGIN
	INSERT INTO tb_compra (codigo_us, codigo_proveedor, fecha_creacion, total)
    VALUES (us, prov, f, total);
    
    SELECT last_insert_id();
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `new_Sale` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `new_Sale`(in us int, in f date, in total float)
BEGIN
	INSERT INTO tb_venta (codigo_us, fecha_creacion, total)
    VALUES (us, f, total);
    
    SELECT last_insert_id();
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `store_Buy_Items` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `store_Buy_Items`(in idP INT, in idC INT, in can INT, in pre FLOAT)
BEGIN
	DECLARE res INT DEFAULT 0;
    
	INSERT INTO tb_detalle_compra(codigo_compra, codigo_prod, cantidad, precio_unit)
    VALUES (idC, idP, can, pre);
    
    SET res = (SELECT inventario FROM tb_producto WHERE codigo_pr = idP) + can;
    
    UPDATE tb_producto
    SET inventario = res
    WHERE codigo_pr = idP;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `store_Sale_Items` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `store_Sale_Items`(in idP INT, in idV INT, in can INT, in pre FLOAT)
BEGIN
	DECLARE res INT DEFAULT 0;

	INSERT INTO tb_detalle_venta(codigo_venta, codigo_prod, cantidad, precio_unit)
    VALUES (idV, idP, can, pre);
    
    SET res = (SELECT inventario FROM tb_producto WHERE codigo_pr = idP) - can;
    
    UPDATE tb_producto
    SET inventario = res
    WHERE codigo_pr = idP;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ups_activo_fa` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ups_activo_fa`(
    IN nCodigo_fa INT
)
BEGIN
    UPDATE tb_familias SET activo = NOT activo WHERE codigo_fa = nCodigo_fa;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ups_activo_pr` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ups_activo_pr`(IN nCodigo_pr INT)
BEGIN
    UPDATE Productos SET activo = NOT activo WHERE codigo_pr = nCodigo_pr;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ups_activo_prov` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ups_activo_prov`(IN nCodigo_prov INT)
BEGIN
    UPDATE tb_proveedor SET activo = NOT activo WHERE codigo_prov = nCodigo_prov;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ups_activo_us` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ups_activo_us`(in nCodigo_us int)
begin
	update tb_usuarios set activo=not activo
		where codigo_us=nCodigo_us;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ups_guardar_fa` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ups_guardar_fa`(
    IN nOpcion INT,
    IN nCodigo_fa INT,
    IN nombre_fa VARCHAR(45),
    IN descripcion_fa VARCHAR(45),
    OUT nCodigo_ou INT
)
BEGIN
    IF nOpcion = 1 THEN -- Nuevo registro
        INSERT INTO tb_familias(
            nombre_fa,
            descripcion_fa
        )
        VALUES(
            nombre_fa,
            descripcion_fa
        );
        SET nCodigo_ou = LAST_INSERT_ID();
    ELSE -- Actualización de registro existente
        UPDATE tb_familias 
        SET  
            nombre_fa = nombre_fa,
            descripcion_fa = descripcion_fa
        WHERE 
            codigo_fa = nCodigo_fa;
        SET nCodigo_ou = nCodigo_fa;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ups_guardar_pr` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ups_guardar_pr`(
    IN nOpcion_pr INT,
    IN nCodigo_pr INT,
    IN cNombre_pr_producto VARCHAR(45),
    IN cDescripcion_pr_producto VARCHAR(180),
    IN nCodigo_manu_producto VARCHAR(20),
    IN nPu_costo_producto DECIMAL(18,2),
    IN nPu_venta_producto DECIMAL(18,2),
    IN nCodigo_prov_producto INT,
    IN nCodigo_us_producto INT,
    IN nCodigo_fa_producto INT,
    OUT nCodigo_ou_pr INT
)
BEGIN
    DECLARE fecha_actual_pr DATETIME;

    SET fecha_actual_pr = NOW();

    IF nOpcion_pr = 1 THEN -- Nuevo registro
        INSERT INTO tb_producto(
            nombre_pr,
            descripcion_pr,
            codigo_manu,
            pu_costo,
            pu_venta,
            codigo_prov, -- Nuevo campo para el código del proveedor
            codigo_us,
            codigo_fa,
            fecha_crea,
            fecha_modifica
        )
        VALUES(
            cNombre_pr_producto,
            cDescripcion_pr_producto,
            nCodigo_manu_producto,
            nPu_costo_producto,
            nPu_venta_producto,
            nCodigo_prov_producto,
            nCodigo_us_producto,
            nCodigo_fa_producto,
            fecha_actual_pr,
            fecha_actual_pr
        );
        SET nCodigo_ou_pr = LAST_INSERT_ID();
    ELSE -- Actualización de registro existente
        UPDATE tb_producto 
        SET  
            nombre_pr = cNombre_pr_producto,
            descripcion_pr = cDescripcion_pr_producto,
            codigo_manu = nCodigo_manu_producto,
            pu_costo = nPu_costo_producto,
            pu_venta = nPu_venta_producto,
            codigo_prov = nCodigo_prov_producto,
            codigo_us = nCodigo_us_producto,
            codigo_fa = nCodigo_fa_producto,
            fecha_modifica = fecha_actual_pr
        WHERE 
            codigo_pr = nCodigo_pr;
        SET nCodigo_ou_pr = nCodigo_pr;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ups_guardar_prov` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ups_guardar_prov`(
    IN nOpcion INT,
    IN nCodigo_prov INT,
    IN cNombre_prov VARCHAR(45),
    IN cDireccion_prov VARCHAR(100),
    IN cTelefono_prov VARCHAR(15),
    IN nCodigo_us INT,
    OUT nCodigo_ou_pr INT
)
BEGIN
    IF nOpcion = 1 THEN
        -- Insertar nuevo proveedor
        INSERT INTO tb_proveedor (nombre_prov, direccion_prov, telefono_prov, codigo_us)
        VALUES (cNombre_prov, cDireccion_prov, cTelefono_prov, nCodigo_us);
        SET nCodigo_ou_pr = LAST_INSERT_ID(); -- Obtener el ID del nuevo registro insertado
    ELSEIF nOpcion = 2 THEN
        -- Actualizar proveedor existente
        UPDATE tb_proveedor
        SET nombre_prov = cNombre_prov,
            direccion_prov = cDireccion_prov,
            telefono_prov = cTelefono_prov,
            codigo_us = nCodigo_us
        WHERE codigo_prov = nCodigo_prov;
        SET nCodigo_ou_pr = nCodigo_prov; -- Devolver el ID del proveedor actualizado
    ELSE
        -- Opción no válida
        SET nCodigo_ou_pr = -1;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ups_guardar_us` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ups_guardar_us`(
    in nOpcion int,
    in nCodigo_us int,
    in cLogin_us varchar(20),
    in cPassword_us varchar(20),
    in cNombre_us varchar(100),
    in nCodigo_ru int,
    out nCodigo_ou int
)
begin
    if nOpcion = 1 then -- Nuevo registro
        insert into tb_usuarios(
            login_us, 
            password_us,
            nombre_us,
            codigo_ru
        )
        values(
            cLogin_us,
            cPassword_us,
            cNombre_us,
            nCodigo_ru
        );
        set nCodigo_ou = last_insert_id();
    else
        update tb_usuarios 
        set  
            password_us = cPassword_us,
            nombre_us = cNombre_us,
            codigo_ru = nCodigo_ru
        where 
            codigo_us = nCodigo_us;
        set nCodigo_ou = nCodigo_us;
    end if;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ups_listado_fa` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ups_listado_fa`()
BEGIN
    SELECT
        codigo_fa,
        nombre_fa,
        descripcion_fa,
        activo
    FROM
        tb_familias
    WHERE
        activo = 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ups_listado_pr` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ups_listado_pr`()
BEGIN
    SELECT
        codigo_pr,
        nombre_pr,
        descripcion_pr,
        codigo_manu,
        pu_costo,
        pu_venta,
        codigo_prov,
        codigo_us,
        codigo_fa,
        fecha_crea,
        fecha_modifica,
        activo
    FROM
        tb_producto;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ups_listado_prov` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ups_listado_prov`()
BEGIN
    SELECT
        codigo_prov,
        nombre_prov,
        direccion_prov,
        telefono_prov,
        codigo_us,
        activo
    FROM
        tb_proveedor
    WHERE
        activo = 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ups_listado_ru` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ups_listado_ru`()
begin
	select descripcion_ru, codigo_ru
    from tb_roles_usuarios
    where activo = 1;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ups_listado_us` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ups_listado_us`(in cTexto varchar(100))
begin 
	select a.codigo_us,
		   a.login_us,
           a.nombre_us,
           b.descripcion_ru,
           a.activo,
           a.codigo_ru
	from tb_usuarios a
    inner join tb_roles_usuarios b 
    on a.codigo_ru = b.codigo_ru
    where upper(concat(trim(cast(a.codigo_us as char)),
				trim(a.login_us),
                trim(a.nombre_us),
                trim(b.descripcion_ru))) like concat('%', upper(trim(cTexto)),'%');

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ups_login_us` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ups_login_us`(in cLogin_us varchar(20),
							  in cPassword_us varchar(20))
begin
	select codigo_us, login_us, nombre_us, descripcion_ru,  a.codigo_ru
    from tb_usuarios a
    join tb_roles_usuarios b 
    on a.codigo_ru = b.codigo_ru
    where a.login_us = cLogin_us 
    and a.password_us = cPassword_us
    and a.activo = 1;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-11  0:40:13
